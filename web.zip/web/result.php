<?php require 'top.php'; ?>
<h3 class="tittle-w3l">Result
       
<span class="heading-style">
    <i></i>
    <i></i>
    <i></i>
</span>
</h3>

<div class="container">
<form name="result" action="" method="post">
<div class="table-responsive">
<table class="table">

</table>
</div>
</form>
</div>
<?php require 'bottom.php'; ?>