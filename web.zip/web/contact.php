<?php require 'top.php'; ?>
	<!-- //navigation -->
	<!-- banner-2 -->
	<div >
<img src="contact.jpg">
	</div>
	<!-- //banner-2 -->
	<!-- page -->
	<div class="services-breadcrumb">
		<div class="agile_inner_breadcrumb">
			<div class="container">
				<ul class="w3_short">
					<li>
						<a href="index.php">Home</a>
						<i>|</i>
					</li>
					<li>contact Us</li>
				</ul>
			</div>
		</div>
	</div>
	<!-- //page -->
	<!-- contact page -->

		
			<!-- tittle heading --><br>
			<h3 class="tittle-w3l">Contact Us
				<span class="heading-style">
					<i></i>
					<i></i>
					<i></i>
				</span>
			</h3>
			<!-- //tittle heading -->
			<!-- contact -->
			<div class="contact agileits">
				<div class="contact-agileinfo">
					
					<div class="contact-right wthree">
						<div class="col-xs-7 contact-text w3-agileits">
							<h4>GET IN TOUCH :</h4>
							<p>
								<i class="fa fa-map-marker"></i>Gujarat University Campus,
								Navrangpura,
								Ahmedabad, 380009 
								Gujarat </p>
							<p>
								<i class="fa fa-phone"></i> Telephone : 079 2630 5972</p>
							<p>
								<i class="fa fa-fax"></i> Working Hours : 8:00 am to 5:30 pm</p>
							<p>
								<i class="fa fa-envelope-o"></i> Email :
								<a href="mailto:ksschool31@yahoo.co.in">ksschool31@yahoo.co.in</a>
							</p>
						</div>
						<div class="col-xs-5 contact-agile">
							<img src="images/contact2.jpg" alt="">
						</div>
						<div class="clearfix"> </div>
				
				
			</div>
			<!-- //contact -->
		</div>
	</div>
	<!-- map -->
	<div class="map w3layouts">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d55565170.29301636!2d-132.08532758867793!3d31.786060306224!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54eab584e432360b%3A0x1c3bb99243deb742!2sUnited+States!5e0!3m2!1sen!2sin!4v1512365940398"
		    allowfullscreen></iframe>
	</div>
	<!-- //map -->
	<!-- newsletter -->
	
	<!-- //newsletter -->
	<!-- footer -->
	<?php require 'bottom.php'; ?>